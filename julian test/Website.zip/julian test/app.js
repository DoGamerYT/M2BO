class App
{
    runApplication()
    {
        console.log("Hello World!");
    
    
    }
}

let app = new App();
app.runApplication();







//darkmode